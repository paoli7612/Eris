<div class="card card-stats">
    <div class="card-header card-header-success card-header-icon">
        <div class="card-icon">
            <i class="material-icons">store</i>
        </div>
        <p class="card-category">Revenue</p>
        <h3 class="card-title">$34,245</h3>
    </div>
    <div class="card-footer">
        <div class="stats">
            <i class="material-icons">date_range</i> Last 24 Hours
        </div>
    </div>
</div>