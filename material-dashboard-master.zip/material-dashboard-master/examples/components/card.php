<div class="card card-stats">
    <div class="card-header card-header-warning card-header-icon">
        <div class="card-icon">
            <i class="material-icons">content_copy</i>
        </div>
        <p class="card-category">Used Space</p>
        <h3 class="card-title">49/50
            <small>GB</small>
        </h3>
    </div>
    <div class="card-footer">
        <div class="stats">
            <i class="material-icons text-danger">warning</i>
            <a href="javascript:;">Get More Space...</a>
        </div>
    </div>
</div>