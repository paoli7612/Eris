<div class="card card-chart">
    <div class="card-header card-header-danger">
        <div class="ct-chart" id="completedTasksChart"></div>
    </div>
    <div class="card-body">
        <h4 class="card-title">Completed Tasks</h4>
        <p class="card-category">Last Campaign Performance</p>
    </div>
    <div class="card-footer">
        <div class="stats">
            <i class="material-icons">access_time</i> campaign sent 2 days ago
        </div>
    </div>
</div>